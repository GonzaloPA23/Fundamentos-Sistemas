﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC1.Modelos
{
    internal class Cliente
    {
        public Cliente() { }
        public String Codigo { get;set; }
        public String Nombre { get; set; }
        public String CorreoElectronico { get; set; }
        public String NumeroTelefono { get; set; }
    }
}
