﻿namespace Lab12.entities
{
    internal class Paciente
    {
        public Paciente() { }
        public String Dni { get; set; }
        public String NombreCompleto { get; set; }
        public int Edad { get; set; }
        public DateTime FechaCita { get; set; }
    }
}
