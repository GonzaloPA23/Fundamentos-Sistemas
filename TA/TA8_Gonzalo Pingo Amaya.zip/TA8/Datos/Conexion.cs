﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Conexion
    {
        public static string cadenaConexion = "Data Source=localhost;Initial Catalog=db_ta8;Integrated Security=True";
    }
}
